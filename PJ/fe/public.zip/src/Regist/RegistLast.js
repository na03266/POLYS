import React from 'react'

function RegistLast() {
  return (
    <div>RegistLast</div>
  )
}

export default RegistLast