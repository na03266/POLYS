import React from 'react'
import FaceDetectionApp from './FaceDetectionApp';

function Confirm() {
  return (
    <div>인증화면 들어갈거임
      <FaceDetectionApp/>
        <h2>움직이지 말고 정면을 보세요</h2>
    </div>
  )
}

export default Confirm