import React from 'react'

function RegistWait() {
  return (
    <div>RegistWait</div>
  )
}

export default RegistWait