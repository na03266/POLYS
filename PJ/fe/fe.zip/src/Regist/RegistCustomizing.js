import React from 'react'

function RegistCustomizing() {
  return (
    <div>RegistCustomizing</div>
  )
}

export default RegistCustomizing