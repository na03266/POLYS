import React from 'react'
import MainLogin from './MainLogin'

function MainLogin1() {
  return (
    <div><MainLogin/></div>
  )
}

export default MainLogin1